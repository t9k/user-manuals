分析预测结果和原始预测数据得到 roc 曲线 。

运行

```bash
python3 roc.py --output ./output \
  --predictions prediction_results \
  --output-schema output_schema.json
```
