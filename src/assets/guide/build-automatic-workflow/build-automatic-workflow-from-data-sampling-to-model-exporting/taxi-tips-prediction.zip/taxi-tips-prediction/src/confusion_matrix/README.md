分析预测结果和原始预测数据得到 confusion matrix 。

运行

```bash
python3 confusion_matrix.py --output ./output \
  --predictions prediction_results \
  --output-schema output_schema.json
```
