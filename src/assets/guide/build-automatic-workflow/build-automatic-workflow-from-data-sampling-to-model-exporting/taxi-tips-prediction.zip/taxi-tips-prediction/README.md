# Taxi tips prediction

本示例展示了一个端到端的机器学习工作流，是一个根据乘客搭乘出租车的位置、路程、用时等特征数据预测是否会付小费的二分类问题，包括数据预处理、模型训练、模型分析、模型上传等步骤。

本目录下的文件结构如下：

* ./data 是用于训练、验证、测试的数据集。
* ./src 是数据预处理、模型训练、模型分析、模型上传等每个步骤的 Python 代码，主要使用了 [TFX 库](https://www.tensorflow.org/tfx)。
* ./docker 是用于编译 Docker 镜像的 Dockerfile。
* ./workflowtemplates 是用于创建 WorkflowTemplate 的 YAML。在网页中创建 WorkflowTemplate 时，您可以将 YAML 的内容直接复制粘贴到网页中。
